<?php
/**
 * Insteon View for com_insteon Component
 * 
 * @package    Insteon
 * @subpackage com_insteon
 * @license  !license!
 *
 * Created with Marco's Component Creator for Joomla! 1.5
 * http://www.mmleoni.net/joomla-component-builder
 *
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the Insteon Component
 *
 * @package		Insteon
 * @subpackage	Components
 */
class InsteonViewStatus extends JView
{
	function display($tpl = null){
		//$data = $this->get('Data');
		//$this->assignRef('data', $data);
		
		//$pagination = $this->get('Pagination');
		//$this->assignRef('pagination', $pagination);
		parent::display($tpl);
	}
}
?>
