<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<?php
JHTML::_('behavior.mootools');
$document = JFactory::getDocument();
$document->addScript( JURI::base().'components/com_insteon/js/status.js' );
$document->addStyleSheet( JURI::base().'components/com_insteon/css/status.css' );
JText::script('COM_INSTEON_DEVICE');
JText::script('COM_INSTEON_STATE');
JText::script('COM_INSTEON_BRIGHTNESS');
JText::script('COM_INSTEON_ON');
JText::script('COM_INSTEON_OFF');
?>

<div id="divstatus">
</div>

