<?php
/**
 * com_insteon default controller
 * 
 * @package    Insteon
 * @subpackage com_insteon
 * @license  !license!
 *
 * Created with Marco's Component Creator for Joomla! 1.5
 * http://www.mmleoni.net/joomla-component-builder
 *
 */

jimport('joomla.application.component.controller');

/**
 * insteon Component Controller
 *
 * @package	Insteon
 */
class InsteonController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display($cachable = false, $urlparams = false)
	{
		parent::display();
	}

}
?>
