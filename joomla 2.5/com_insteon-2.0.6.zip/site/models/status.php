<?php
/**
 * Insteon Model for Insteon World Component
 * 
 * @package    Insteon
 * @subpackage com_insteon
 * @license  !license!
 *
 * Created with Marco's Component Creator for Joomla! 1.5
 * http://www.mmleoni.net/joomla-component-builder
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );

/**
 * Insteon Model
 *
 * @package    Joomla.Components
 * @subpackage 	Insteon
 */
class InsteonModelStatus extends JModel{
	
	/**
	 * Insteondeviceslist data array for tmp store
	 *
	 * @var array
	 */
	private $_data;

	/**
	* Pagination object
	* @var object
	*/
	private $_pagination = null;

	/*
	 * Constructor
	 *
	 */
	function __construct(){
		parent::__construct();

		$config = JFactory::getConfig();

		$this->setState('limit',999);
		$this->setState('limitstart', JRequest::getVar('limitstart', 0, '', 'int'));

		$this->setState('limitstart', ($this->getState('limit') != 0 ? (floor($this->getState('limitstart') / $this->getState('limit')) * $this->getState('limit')) : 0));

		$this->setState('filter_order', JRequest::getCmd('filter_order', 'name'));
		$this->setState('filter_order_dir', JRequest::getCmd('filter_order_Dir', 'ASC'));
	}

	
	/**
	 * Gets the data
	 * @return mixed The data to be displayed to the user
	 */
	public function getData(){
		// Lets load the data if it doesn't already exist
		if (empty( $this->_data )){
			$recordSet = $this->getTable('insteondevices');
			$db = JFactory::getDBO();
		  $query  = 'SELECT c.*, a.description AS adescription FROM `#__insteondevices` AS c ';
      $query .= 'LEFT JOIN #__insteonareas AS a ON a.id = c.insteonareas_id ';
			$query .= 'WHERE c.published = 1 and c.display = 1 ';
			$query .= 'ORDER BY adescription, ordering ';
			$this->_data = $this->_getList( $query, $this->getState('limitstart'), $this->getState('limit') );
		}
		return $this->_data;
	}

	/**
	 * Gets the number of published records
	 * @return int
	 */
	public function getTotal(){
		$db = JFactory::getDBO();
		$recordSet = $this->getTable('insteondevices');
		$db->setQuery( 'SELECT COUNT(*) FROM `#__insteondevices` WHERE  published = 1 and display = 1');
		return $db->loadResult();
	}
	
	/**
	 * Gets the Pagination Object
	 * @return object JPagination
	 */
	public function getPagination(){
		// Load the content if it doesn't already exist
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
		}
		return $this->_pagination;
	}
	
	
}
