<?php
/**
 * Joomla! 1.5 component Our home
 *
 * @version $Id: controller.php 2010-03-08 14:10:53 svn $
 * @author Tod Price aka htrn
 * @package Joomla
 * @subpackage Our home
 * @license GNU/GPL
 *
 * Home Automation component
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * Our home Component Controller
 */
class InsteonControllerStatus extends JController {
	function display($cachable = false, $urlparams = false) {
        // Make sure we have a default view
        if( !JRequest::getVar( 'view' )) {
		    JRequest::setVar('view', 'status' );
        }
    $view = $this->getView( 'Status', 'html' );
    $view->setModel( $this->getModel( 'status' ), true );
    $view->display();
    //parent::display();
	}
function sendcommand()
  {
	$app	= JFactory::getApplication();
	$params =  $app->getParams('com_insteon');
	$address = $params->get( 'insteonaddress', '127.0.0.1' ); 
	$port = $params->get( 'insteonport', '9091' ); 

  $command = JRequest::getVar('command','');
  $device = JRequest::getVar('device','');

  echo file_get_contents("http://$address:$port/insteon?device=".$device."&command=".$command);
  }
function statusjson()
	{
    $document = JFactory::getDocument();
    $document->setMimeEncoding( 'application/json' );
	$app	= JFactory::getApplication();
	$params =  $app->getParams('com_insteon');

    $model = $this->getModel('status');
    $rows = $model->getData();
    $json = array();
    $i = 0;
	foreach ($rows as &$row) {
        $json[$i]['id']=$row->id;
        $json[$i]['areaid']=$row->insteonareas_id;
        $json[$i]['friendlyname']    =$row->friendlyname;
        $json[$i]['device']         =$row->device;
        $json[$i]['description']    =$row->description;
        $json[$i]['type']           =$row->type;
        $json[$i]['defaultlinkdata']=$row->defaultlinkdata;
        $json[$i]['engine']         =$row->engine;
        $json[$i]['state']          =$row->state;
        $json[$i]['brightness']     =$row->brightness;
        $json[$i]['display']        =$row->display;
        $json[$i]['lastupdate']     =$row->lastupdate;
        $json[$i]['adescription']   =$row->adescription;
        $i++;
    }
    echo json_encode($json);
}
	function jsonstatus() {
		$app	= JFactory::getApplication();
		$params =  $app->getParams('com_insteon');
		$address = $params->get( 'insteonaddress', '127.0.0.1' ); 
		$port = $params->get( 'insteonport', '9091' ); 
		
		$document =& JFactory::getDocument();
		$document->setMimeEncoding('application/json');
		$document->setCharset('');
		if (isset($_SERVER['HTTP_ACCEPT_ENCODING'])) {
			unset($_SERVER['HTTP_ACCEPT_ENCODING']);
		}
		echo file_get_contents("http://$address:$port/insteon?command=json");
	
	}

}
?>