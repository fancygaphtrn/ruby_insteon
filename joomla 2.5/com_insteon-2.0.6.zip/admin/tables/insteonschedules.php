<?php
/**
* @version		$Id:insteonschedules.php  1 2013-09-20 14:02:35Z HTRN $
* @package		Insteon
* @subpackage 	Tables
* @copyright	Copyright (C) 2011, Tod Price. All rights reserved.
* @license #http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
* Jimtawl TableInsteonschedules class
*
* @package		Insteon
* @subpackage	Tables
*/
class TableInsteonschedules extends JTable
{
	
   /** @var int id- Primary Key  **/
   public $id = null;

   /** @var varchar description  **/
   public $description = null;

   /** @var tinyint published  **/
   public $published = null;

   /** @var int ordering  **/
   public $ordering = null;

   /** @var int timecode  **/
   public $timecode = null;

   /** @var int timeoffset  **/
   public $timeoffset = null;

   /** @var varchar stime  **/
   public $stime = null;

   /** @var tinyint dmon  **/
   public $dmon = "1";

   /** @var tinyint dtue  **/
   public $dtue = "1";

   /** @var tinyint dwed  **/
   public $dwed = "1";

   /** @var tinyint dthu  **/
   public $dthu = "1";

   /** @var tinyint dfri  **/
   public $dfri = "1";

   /** @var tinyint dsat  **/
   public $dsat = "1";

   /** @var tinyint dsun  **/
   public $dsun = "1";




	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 * @since 1.0
	 */
	public function __construct(& $db) 
	{
		parent::__construct('#__insteonschedules', 'id', $db);
	}

	/**
	* Overloaded bind function
	*
	* @acces public
	* @param array $hash named array
	* @return null|string	null is operation was satisfactory, otherwise returns an error
	* @see JTable:bind
	* @since 1.5
	*/
	public function bind($array, $ignore = '')
	{ 
		
		return parent::bind($array, $ignore);		
	}

	/**
	 * Overloaded check method to ensure data integrity
	 *
	 * @access public
	 * @return boolean True on success
	 * @since 1.0
	 */
	public function check()
	{
		if ($this->id === 0) {
			//get next ordering

			
			$this->ordering = $this->getNextOrder( );

		}


		/** check for valid name */
		/**
		if (trim($this->description) == '') {
			$this->setError(JText::_('Your Insteonschedules must contain a description.')); 
			return false;
		}
		**/		

		return true;
	}
}
