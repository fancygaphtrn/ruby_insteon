<?php
/**
* @version		$Id:insteondevices.php  1 2013-09-20 18:46:22Z HTRN $
* @package		Insteon
* @subpackage 	Tables
* @copyright	Copyright (C) 2011, Tod Price. All rights reserved.
* @license #http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
* Jimtawl TableInsteondevices class
*
* @package		Insteon
* @subpackage	Tables
*/
class TableInsteondevices extends JTable
{
	
   /** @var int id- Primary Key  **/
   public $id = null;

   /** @var varchar friendlyname  **/
   public $friendlyname = null;

   /** @var varchar description  **/
   public $description = null;

   /** @var tinyint published  **/
   public $published = null;

   /** @var int ordering  **/
   public $ordering = null;

   /** @var insteoninsteonareas insteonareas_id  **/
   public $insteonareas_id = null;

   /** @var varchar device  **/
   public $device = null;

   /** @var tinyint icontroller  **/
   public $icontroller = null;

   /** @var varchar ipaddress  **/
   public $ipaddress = null;

   /** @var int port  **/
   public $port = null;

   /** @var varchar username  **/
   public $username = null;

   /** @var varchar password  **/
   public $password = null;

   /** @var varchar type  **/
   public $type = null;

   /** @var varchar defaultlinkdata  **/
   public $defaultlinkdata = null;

   /** @var varchar engine  **/
   public $engine = null;

   /** @var varchar state  **/
   public $state = null;

   /** @var varchar brightness  **/
   public $brightness = null;

   /** @var tinyint display  **/
   public $display = null;

   /** @var timestamp lastupdate  **/
   public $lastupdate = "CURRENT_TIMESTAMP";




	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 * @since 1.0
	 */
	public function __construct(& $db) 
	{
		parent::__construct('#__insteondevices', 'id', $db);
	}

	/**
	* Overloaded bind function
	*
	* @acces public
	* @param array $hash named array
	* @return null|string	null is operation was satisfactory, otherwise returns an error
	* @see JTable:bind
	* @since 1.5
	*/
	public function bind($array, $ignore = '')
	{ 
		
		return parent::bind($array, $ignore);		
	}

	/**
	 * Overloaded check method to ensure data integrity
	 *
	 * @access public
	 * @return boolean True on success
	 * @since 1.0
	 */
	public function check()
	{
		if ($this->id === 0) {
			//get next ordering

			
			$this->ordering = $this->getNextOrder( );

		}


		/** check for valid name */
		/**
		if (trim($this->friendlyname) == '') {
			$this->setError(JText::_('Your Insteondevices must contain a friendlyname.')); 
			return false;
		}
		**/		

		return true;
	}
}
