<?php
/**
* @version		$Id: default_controller.php 96 2011-08-11 06:59:32Z michel $
* @package		Insteon
* @subpackage 	Controllers
* @copyright	Copyright (C) 2011, Tod Price. All rights reserved.
* @license #http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * InsteonInsteondeviceslinks Controller
 *
 * @package    Insteon
 * @subpackage Controllers
 */
class InsteonControllerInsteondeviceslinks extends InsteonController
{
	/**
	 * Constructor
	 */
	protected $_viewname = 'insteondeviceslinks'; 
	 
	public function __construct($config = array ()) 
	{
		parent :: __construct($config);
		JRequest :: setVar('view', $this->_viewname);

	}		
	public function publish() 
	{
		// Check for request forgeries
		JRequest :: checkToken() or jexit('Invalid Token');

		$cid = JRequest :: getVar('cid', array (), 'post', 'array');
		JArrayHelper :: toInteger($cid);

		if (count($cid) < 1) {
			JError :: raiseError(500, JText :: _('Select an item to publish'));
		}

		$model = $this->getModel('insteondeviceslinks');
		if (!$model->publish($cid, 1)) {
			echo "<script> alert('" . $model->getError(true) . "'); window.history.go(-1); </script>\n";
		}

		$this->setRedirect('index.php?option=com_insteon&view=insteondeviceslinks');
	}

	public function unpublish() 
	{
		// Check for request forgeries
		JRequest :: checkToken() or jexit('Invalid Token');

		$cid = JRequest :: getVar('cid', array (), 'post', 'array');
		JArrayHelper :: toInteger($cid);

		if (count($cid) < 1) {
			JError :: raiseError(500, JText :: _('Select an item to unpublish'));
		}

		$model = $this->getModel('insteondeviceslinks');
		if (!$model->publish($cid, 0)) {
			echo "<script> alert('" . $model->getError(true) . "'); window.history.go(-1); </script>\n";
		}

		$this->setRedirect('index.php?option=com_insteon&view='.$this->_viewname);
	}
	public function orderup() 
	{
		// Check for request forgeries
		JRequest :: checkToken() or jexit('Invalid Token');

		$model = $this->getModel('insteondeviceslinks');
		$model->move(-1);

		$this->setRedirect('index.php?option=com_insteon&view='.$this->_viewname);
	}

	public function orderdown() 
	{
		// Check for request forgeries
		JRequest :: checkToken() or jexit('Invalid Token');

		$model = $this->getModel('insteondeviceslinks');
		$model->move(1);

		$this->setRedirect('index.php?option=com_insteon&view='.$this->_viewname);
	}

	public function saveorder() 
	{
		// Check for request forgeries
		JRequest :: checkToken() or jexit('Invalid Token');

		$cid = JRequest :: getVar('cid', array (), 'post', 'array');
		$order = JRequest :: getVar('order', array (), 'post', 'array');
		JArrayHelper :: toInteger($cid);
		JArrayHelper :: toInteger($order);

		$model = $this->getModel('insteondeviceslinks');
		$model->saveorder($cid, $order);

		$msg = JText :: _('New ordering saved');
		$this->setRedirect('index.php?option=com_insteon&view='.$this->_viewname, $msg);
	}	
    public function graph(){
/*
		$model = $this->getModel( 'insteondeviceslinks' );
        $rows = $model->getGraph();

        $filename = JPATH_BASE.'/tmp/graph.dot';
echo $filename;
        $handle = fopen($filename, "w");
        if ($handle) {
            fputs($handle, "digraph G{\n");
            fputs($handle, "   size =\"9,9\"\n");
            fputs($handle, "   graph[fontsize =12]\n");
            fputs($handle, "   graph[fontname=\"Helvetica\"]\n");
            fputs($handle, "   node[fontsize =12]\n");
            fputs($handle, "   node[fontname=\"Helvetica\"]\n");
            fputs($handle, "   edge[fontsize =12]\n");
            fputs($handle, "   edge[fontname=\"Helvetica\"]\n");
            fputs($handle, "   rankdir=LR\n");
            $fdevice = '';
            foreach($rows as $row) {
                if ($fdevice != $row->fdevice) {
                    $fname = str_replace(' ', '_',$row->ffriendlyname).'_'.$row->fdevice;
                    if ($row->icontroller == 1) {
                        $label = "shape=polygon,sides=4,label=\"$row->afdescription $row->ffriendlyname\\n$row->fdevice\"";
                    } else {
                        $label = "label=\"$row->afdescription $row->ffriendlyname\\n$row->fdevice\"";
                    }
                    $data = "   $fname [$label]\n";
                    fputs($handle, $data);
                    $fdevice = $row->fdevice;
                }
            }
            foreach($rows as $row) {
                if (hexdec($row->flags) & 0x40) {
                    $fname = str_replace(' ', '_',$row->ffriendlyname).'_'.$row->fdevice;
                    $tname = str_replace(' ', '_',$row->tfriendlyname).'_'.$row->tdevice;
                    $data = "   $fname -> $tname [label=\"$row->devicegroup\"]\n";
                    fputs($handle, $data);
                }
            }
            fputs($handle, "}\n");
            fclose($handle);
            exec("dot -Tpng -O $filename");
        } else { 
			    return ("ERROR: Error writing file $filename");
        }
        //$this->setRedirect( 'index.php?option=com_insteon&view=linkgraph' );
*/
 	}
}// class
?>