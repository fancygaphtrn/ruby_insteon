<?php
/**
* @version		$Id: #name#.php 111 2012-02-24 18:37:06Z michel $
* @package		Insteon
* @subpackage 	Controllers
* @copyright	Copyright (C) 2011, Tod Price. All rights reserved.
* @license #http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * InsteonDefault Controller
 *
 * @package    Insteon
 * @subpackage Controllers
 */
class InsteonControllerDefault extends InsteonController
{
	/**
	 * Constructor
	 */
	protected $_viewname = 'default'; 
	 
	public function __construct($config = array ()) 
	{
		parent :: __construct($config);
		JRequest :: setVar('view', $this->_viewname);

	}
	
	function cancel()
	{
		// Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' );

		$this->setRedirect( 'index.php?option=com_insteon&view=default' );
		
		$model = $this->getModel('default');

		$model ->checkin();
	}	
	
	function edit() 
	{
		$document =& JFactory::getDocument();

		$viewType	= $document->getType();
		$viewType	= $document->getType();
		$viewName	= JRequest::getCmd( 'view', $this->_viewname);
				
		$view = & $this->getView( $viewName, $viewType);
		
		//Some Code here
		
		$view->setLayout('form');
		JRequest::setVar( 'hidemainmenu', 1 );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar( 'view', $this->_viewname);
		JRequest::setVar( 'edit', true );
				
		$view->display();
	}
	

	/**
	 * stores the item
	 */
	function save() 
	{
		// Check for request forgeries
		JRequest :: checkToken() or jexit('Invalid Token');
		
		//Do something
		
		
		switch ($this->getTask())
		{
			case 'apply':
				$link = 'index.php?option=com_insteon&view=default.&task=edit&cid[]=1' ;
				break;

			case 'save':
			default:
				$link = 'index.php?option=com_insteon&view=default';
				break;
		}
        
		$this->setRedirect($link, $msg);
	}
		
	
}// class
?>