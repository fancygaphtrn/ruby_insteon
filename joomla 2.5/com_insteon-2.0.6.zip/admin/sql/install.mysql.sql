-- --------------------------------------------------------

--
-- Table structure for table `jos_insteonareas`
--

CREATE TABLE IF NOT EXISTS `jos_insteonareas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(40) NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_insteoncommands`
--

CREATE TABLE IF NOT EXISTS `jos_insteoncommands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insteonevents_id` int(11) NOT NULL,
  `description` varchar(40) DEFAULT NULL,
  `commandtype` varchar(1) NOT NULL DEFAULT '0',
  `commandprefix` varchar(4) DEFAULT NULL,
  `commanddevice` varchar(6) DEFAULT NULL,
  `commandflag` varchar(2) DEFAULT NULL,
  `command` varchar(50) DEFAULT NULL,
  `delay` int(4) NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL,
  `jsondata` text,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `insteonevents_id` (`insteonevents_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=86 ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_insteondevices`
--

CREATE TABLE IF NOT EXISTS `jos_insteondevices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insteonareas_id` int(11) NOT NULL,
  `friendlyname` varchar(40) DEFAULT NULL,
  `device` varchar(6) DEFAULT NULL,
  `controller` varchar(6) NOT NULL,
  `description` varchar(40) DEFAULT NULL,
  `icontroller` tinyint(1) DEFAULT '0',
  `ipaddress` varchar(15) DEFAULT NULL,
  `port` int(5) DEFAULT NULL,
  `username` varchar(40) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `type` varchar(6) DEFAULT NULL,
  `defaultlinkdata` varchar(6) DEFAULT NULL,
  `engine` varchar(2) DEFAULT NULL,
  `state` varchar(12) DEFAULT NULL,
  `brightness` varchar(12) DEFAULT NULL,
  `display` tinyint(1) DEFAULT '0',
  `lastupdate` timestamp NULL DEFAULT NULL,
  `hopsaverage` decimal(7,6) DEFAULT '0.000000',
  `hopscount` int(11) DEFAULT '0',
  `hopsmax` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `device` (`device`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=146 ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_insteondeviceslinks`
--

CREATE TABLE IF NOT EXISTS `jos_insteondeviceslinks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fromdeviceid` int(11) DEFAULT NULL,
  `todeviceid` int(11) DEFAULT NULL,
  `devicegroup` varchar(12) DEFAULT NULL,
  `address` varchar(4) DEFAULT NULL,
  `flags` varchar(2) DEFAULT NULL,
  `linkdata` varchar(6) DEFAULT NULL,
  `state` varchar(12) DEFAULT NULL,
  `brightness` varchar(12) DEFAULT NULL,
  `ramp` varchar(12) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1231 ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_insteonevents`
--

CREATE TABLE IF NOT EXISTS `jos_insteonevents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(40) DEFAULT NULL,
  `eventtype` varchar(1) NOT NULL DEFAULT '0',
  `from` varchar(6) DEFAULT NULL,
  `to` varchar(6) DEFAULT NULL,
  `command` varchar(4) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_insteonscheduledetail`
--

CREATE TABLE IF NOT EXISTS `jos_insteonscheduledetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insteonevents_id` int(11) DEFAULT NULL,
  `insteonschedules_id` int(11) DEFAULT NULL,
  `description` varchar(40) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `insteonevents_id` (`insteonevents_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- Table structure for table `jos_insteonschedules`
--

CREATE TABLE IF NOT EXISTS `jos_insteonschedules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(40) DEFAULT NULL,
  `timecode` int(1) DEFAULT '0',
  `timeoffset` int(5) DEFAULT '0',
  `stime` varchar(5) DEFAULT NULL,
  `dmon` tinyint(1) DEFAULT '1',
  `dtue` tinyint(1) DEFAULT '1',
  `dwed` tinyint(1) DEFAULT '1',
  `dthu` tinyint(1) DEFAULT '1',
  `dfri` tinyint(1) DEFAULT '1',
  `dsat` tinyint(1) DEFAULT '1',
  `dsun` tinyint(1) DEFAULT '1',
  `published` tinyint(1) DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

