DROP TABLE IF EXISTS #__insteonareas;
DROP TABLE IF EXISTS #__insteoncommands;
DROP TABLE IF EXISTS #__insteondevices;
DROP TABLE IF EXISTS #__insteondeviceslinks;
DROP TABLE IF EXISTS #__insteonevents;
DROP TABLE IF EXISTS #__insteonscheduledetail;
DROP TABLE IF EXISTS #__insteonschedules;
