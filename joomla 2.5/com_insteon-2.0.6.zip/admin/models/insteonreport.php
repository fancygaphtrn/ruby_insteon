  <?php
 defined('_JEXEC') or die('Restricted access');
/**
* @version		$Id:insteonreport.php  1 2013-09-20 14:02:35Z HTRN $
* @package		Insteon
* @subpackage 	Models
* @copyright	Copyright (C) 2011, Tod Price. All rights reserved.
* @license #http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*/
 defined('_JEXEC') or die('Restricted access');
/**
 * InsteonModelInsteonreport
 * @author Tod Price
 */
 
 
class InsteonModelInsteonreport  extends JModelLegacy { 
	/**
	 * Items data array
	 *
	 * @var array
	 */
	protected $_data = null;

	/**
	 * JQuery
	 *
	 * @var object
	 */
	protected $_query;

	public function __construct()
	{
		parent::__construct();
		
		$this->_query = $this->_db->getQuery(true); 
	}
	/**
	* Method to build the query
	*
	* @access private
	* @return string query	
	*/
	public function getData()
	{
		// Lets load the content if it doesn't already exist
	   
		$query = 'SELECT a.* from #__insteonevents AS a WHERE a.published = 1 ORDER BY a.description';
		$rows = $this->_getList($query);

        foreach($rows as $row) {
			$query = 'SELECT a.* from #__insteonscheduledetail AS a WHERE a.insteonevents_id = '.$row->id.' and a.published = 1';
			$row->scheduledetails = $this->_getList($query);
			
			foreach($row->scheduledetails as $sdrow) {
				$query = 'SELECT a.* from #__insteonschedules AS a WHERE a.id = '.$sdrow->insteonschedules_id.' and a.published = 1';
				$sdrow->schedules = $this->_getList($query);
			}
			$query = 'SELECT a.* from #__insteoncommands AS a WHERE a.insteonevents_id = '.$row->id.' and a.published = 1 ORDER BY a.delay, a.description';
			$row->commands = $this->_getList($query);
		}
		return $rows;
		
	}
	
}
?>