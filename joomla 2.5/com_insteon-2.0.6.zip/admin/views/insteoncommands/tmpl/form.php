<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

// Set toolbar items for the page
$edit		= JRequest::getVar('edit', true);
$text = !$edit ? JText::_( 'COM_INSTEON_NEW' ) : JText::_( 'COM_INSTEON_EDIT' );
JToolBarHelper::title(   JText::_( 'COM_INSTEON_INSTEON_COMMANDS' ).': <small><small>[ ' . $text.' ]</small></small>' );
JToolBarHelper::apply();
JToolBarHelper::save();
if (!$edit) {
	JToolBarHelper::cancel();
} else {
	JToolBarHelper::save2copy();
	// for existing items the button is renamed `close`
	JToolBarHelper::cancel( 'cancel', 'JTOOLBAR_CLOSE' );
}
?>

<script language="javascript" type="text/javascript">


Joomla.submitbutton = function(task)
{
	if (task == 'cancel' || document.formvalidator.isValid(document.id('adminForm'))) {
		Joomla.submitform(task, document.getElementById('adminForm'));
	}
}
  var origText;
  function update_insteon(){ 
    var i = $('optionalInsteon');
    var d = $('optionalDirectv');
    var e = $('optionalEmail');
    if ($('jform_commandtype0').checked) {
		$('jform_command-lbl').innerText = origText;
        i.style.cssText = 'display:block;';
        d.style.cssText = 'display:block;';
        e.style.cssText = 'display:none;';
	}
    if ($('jform_commandtype1').checked) {
        i.style.cssText = 'display:none;';
        d.style.cssText = 'display:none;';
        e.style.cssText = 'display:block;';
 	}
    if ($('jform_commandtype2').checked) {
		$('jform_command-lbl').innerText = '<?php echo JText::_('Directv');?>';
        i.style.cssText = 'display:none;';
        d.style.cssText = 'display:block;';
        e.style.cssText = 'display:none;';
	}
  } 
window.addEvent('domready', function() {
	origText = 	$('jform_command-lbl').innerText;
    update_insteon();
	var elems = $('jform_commandtype').getElements('*[id^=jform_commandtype]');
	elems.each(function(item, index){
		item.addEvent('click', function() {
			update_insteon();
		});
	});
});
window.addEvent('domready', function() {
	focusField('jform_desc');
});
function focusField(id){
    var inputField = document.getElementById(id);
    if (inputField != null && inputField.value.length != 0){
        if (inputField.createTextRange){
            var FieldRange = inputField.createTextRange();
            FieldRange.moveStart('character',inputField.value.length);
            FieldRange.collapse();
            FieldRange.select();
        }else if (inputField.selectionStart || inputField.selectionStart == '0') {
            var elemLen = inputField.value.length;
            inputField.selectionStart = elemLen;
            inputField.selectionEnd = elemLen;
            inputField.focus();
        }
    }else{
        inputField.focus();
    }
}

</script>

	 	<form method="post" action="index.php" id="adminForm" name="adminForm">
	 	<div class="col <?php if(version_compare(JVERSION,'3.0','lt')):  ?>width-60  <?php endif; ?>span8 form-horizontal fltlft">
		  <fieldset class="adminform">
			<legend><?php echo JText::_( 'COM_INSTEON_DETAILS' ); ?></legend>
							
				<?php echo $this->form->getLabel('description'); ?>
				
				<?php echo $this->form->getInput('description');  ?>
					
				<?php echo $this->form->getLabel('insteonevents_id'); ?>
				
				<?php echo $this->form->getInput('insteonevents_id');  ?>
				
				<?php echo $this->form->getLabel('commandtype'); ?>
				
				<?php echo $this->form->getInput('commandtype');  ?>
					
				<div id="optionalInsteon">
	
				<?php echo $this->form->getLabel('commandprefix'); ?>
				
				<?php echo $this->form->getInput('commandprefix');  ?>
					
				<?php echo $this->form->getLabel('commanddevice'); ?>
				
				<?php echo $this->form->getInput('commanddevice');  ?>
					
				<?php echo $this->form->getLabel('commandflag'); ?>
				
				<?php echo $this->form->getInput('commandflag');  ?>
				</div>
				<div id="optionalDirectv">
					
				<?php echo $this->form->getLabel('command'); ?>
				
				<?php echo $this->form->getInput('command');  ?>
				</div>
				
				<?php echo $this->form->getLabel('delay'); ?>
				
				<?php echo $this->form->getInput('delay');  ?>
				
				<div id="optionalEmail">
	
				<?php echo $this->form->getLabel('email'); ?>
				
				<?php echo $this->form->getInput('email');  ?>
				</div>
				
				<div class="clr"></div>
					
					
				<?php echo $this->form->getLabel('jsondata'); ?>
				
					
				<div class="clr"></div>
					
				<?php echo $this->form->getInput('jsondata');  ?>
					
					
							
				<?php echo $this->form->getLabel('published'); ?>
				
				<?php echo $this->form->getInput('published');  ?>
			
						
          </fieldset>                      
        </div>
        <div class="col <?php if(version_compare(JVERSION,'3.0','lt')):  ?>width-30  <?php endif; ?>span2 fltrgt">
			        

        </div>                   
		<input type="hidden" name="option" value="com_insteon" />
	    <input type="hidden" name="cid[]" value="<?php echo $this->item->id ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="view" value="insteoncommands" />
		<?php echo JHTML::_( 'form.token' ); ?>
	</form>