<?php

// no direct access
defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.html.html.tabs' );
JToolBarHelper::title(   JText::_( 'Insteon' ), 'generic.png' );
JToolBarHelper::preferences('com_insteon', '350');
?>
