<?php 
/**
* @version		$Id: view.html.php 125 2012-10-09 11:09:48Z michel $
* @package		Insteon
* @subpackage 	Views
* @copyright	Copyright (C) 2011, Tod Price. All rights reserved.
* @license #http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');
 
 
class InsteonViewDefault  extends JViewLegacy {

	public function display($tpl = null) 
	{
		jimport('joomla.application.component.helper'); // Import component helper library
		$params = JComponentHelper::getParams('com_insteon'); // Get parameter helper

        $this->assignRef('params', $params);		    
		parent::display();
	}
}
?>