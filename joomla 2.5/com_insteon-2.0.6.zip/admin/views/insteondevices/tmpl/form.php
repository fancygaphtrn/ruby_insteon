<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

// Set toolbar items for the page
$edit		= JRequest::getVar('edit', true);
$text = !$edit ? JText::_( 'COM_INSTEON_NEW' ) : JText::_( 'COM_INSTEON_EDIT' );
JToolBarHelper::title(   JText::_( 'COM_INSTEON_INSTEON_DEVICES' ).': <small><small>[ ' . $text.' ]</small></small>' );
JToolBarHelper::apply();
JToolBarHelper::save();
if (!$edit) {
	JToolBarHelper::cancel();
} else {
	JToolBarHelper::save2copy();
	// for existing items the button is renamed `close`
	JToolBarHelper::cancel( 'cancel', 'JTOOLBAR_CLOSE' );
}
?>

<script language="javascript" type="text/javascript">


Joomla.submitbutton = function(task)
{
	if (task == 'cancel' || document.formvalidator.isValid(document.id('adminForm'))) {
		Joomla.submitform(task, document.getElementById('adminForm'));
	}
}
window.addEvent('domready', function() {
	focusField('jform_device');
});
function focusField(id){
    var inputField = document.getElementById(id);
    if (inputField != null && inputField.value.length != 0){
        if (inputField.createTextRange){
            var FieldRange = inputField.createTextRange();
            FieldRange.moveStart('character',inputField.value.length);
            FieldRange.collapse();
            FieldRange.select();
        }else if (inputField.selectionStart || inputField.selectionStart == '0') {
            var elemLen = inputField.value.length;
            inputField.selectionStart = elemLen;
            inputField.selectionEnd = elemLen;
            inputField.focus();
        }
    }else{
        inputField.focus();
    }
}

</script>

	 	<form method="post" action="index.php" id="adminForm" name="adminForm">
	 	<div class="col <?php if(version_compare(JVERSION,'3.0','lt')):  ?>width-60  <?php endif; ?>span8 form-horizontal fltlft">
		  <fieldset class="adminform">
			<legend><?php echo JText::_( 'COM_INSTEON_DETAILS' ); ?></legend>
					
				<?php echo $this->form->getLabel('device'); ?>
				
				<?php echo $this->form->getInput('device');  ?>
							
				<?php echo $this->form->getLabel('friendlyname'); ?>
				
				<?php echo $this->form->getInput('friendlyname');  ?>
					
				<?php echo $this->form->getLabel('insteonareas_id'); ?>
				
				<?php echo $this->form->getInput('insteonareas_id');  ?>
					
				<?php echo $this->form->getLabel('description'); ?>
					
				<?php echo $this->form->getInput('description');  ?>
					
				<?php echo $this->form->getLabel('display'); ?>
					
				<?php echo $this->form->getInput('display');  ?>
							
				<?php echo $this->form->getLabel('controller'); ?>
				
				<?php echo $this->form->getInput('controller');  ?>
					
				<?php echo $this->form->getLabel('icontroller'); ?>
				
				<?php echo $this->form->getInput('icontroller');  ?>
					
				<?php echo $this->form->getLabel('ipaddress'); ?>
				
				<?php echo $this->form->getInput('ipaddress');  ?>
					
				<?php echo $this->form->getLabel('port'); ?>
				
				<?php echo $this->form->getInput('port');  ?>
					
				<?php echo $this->form->getLabel('username'); ?>
				
				<?php echo $this->form->getInput('username');  ?>
					
				<?php echo $this->form->getLabel('password'); ?>
				
				<?php echo $this->form->getInput('password');  ?>
					
				<?php echo $this->form->getLabel('type'); ?>
				
				<?php echo $this->form->getInput('type');  ?>
					
				<?php echo $this->form->getLabel('defaultlinkdata'); ?>
				
				<?php echo $this->form->getInput('defaultlinkdata');  ?>
					
				<?php echo $this->form->getLabel('engine'); ?>
				
				<?php echo $this->form->getInput('engine');  ?>
					
				<?php echo $this->form->getLabel('state'); ?>
				
				<?php echo $this->form->getInput('state');  ?>
					
				<?php echo $this->form->getLabel('brightness'); ?>
				
				<?php echo $this->form->getInput('brightness');  ?>
					
				<?php echo $this->form->getLabel('hopsaverage'); ?>
				
				<?php echo $this->form->getInput('hopsaverage');  ?>
					
				<?php echo $this->form->getLabel('hopscount'); ?>
				
				<?php echo $this->form->getInput('hopscount');  ?>
					
				<?php echo $this->form->getLabel('hopsmax'); ?>
				
				<?php echo $this->form->getInput('hopsmax');  ?>
							
				<?php echo $this->form->getLabel('published'); ?>
				
				<?php echo $this->form->getInput('published');  ?>
			
						
          </fieldset>                      
        </div>
        <div class="col <?php if(version_compare(JVERSION,'3.0','lt')):  ?>width-30  <?php endif; ?>span2 fltrgt">
			        

        </div>                   
		<input type="hidden" name="option" value="com_insteon" />
	    <input type="hidden" name="cid[]" value="<?php echo $this->item->id ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="view" value="insteondevices" />
		<?php echo JHTML::_( 'form.token' ); ?>
	</form>