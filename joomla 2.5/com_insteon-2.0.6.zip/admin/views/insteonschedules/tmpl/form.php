<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

// Set toolbar items for the page
$edit		= JRequest::getVar('edit', true);
$text = !$edit ? JText::_( 'COM_INSTEON_NEW' ) : JText::_( 'COM_INSTEON_EDIT' );
JToolBarHelper::title(   JText::_( 'COM_INSTEON_INSTEON_SCHEDULES' ).': <small><small>[ ' . $text.' ]</small></small>' );
JToolBarHelper::apply();
JToolBarHelper::save();
if (!$edit) {
	JToolBarHelper::cancel();
} else {
	JToolBarHelper::save2copy();
	// for existing items the button is renamed `close`
	JToolBarHelper::cancel( 'cancel', 'JTOOLBAR_CLOSE' );
}
?>

<script language="javascript" type="text/javascript">


Joomla.submitbutton = function(task)
{
	if (task == 'cancel' || document.formvalidator.isValid(document.id('adminForm'))) {
		Joomla.submitform(task, document.getElementById('adminForm'));
	}
}
  function update_timecode(){ 
    var t;
    l = $('jform_stime-lbl');
	t = $('jform_stime');
    if ($('jform_timecode0').checked || $('jform_timecode1').checked || $('jform_timecode2').checked) {
        l.style.cssText = 'display:block;';
        t.style.cssText = 'display:block;';
    } else {
        l.style.cssText = 'display:none;';
        t.style.cssText = 'display:none;';
    }
  } 
window.addEvent('domready', function() {
    update_timecode();
	var elems = $('jform_timecode').getElements('*[id^=jform_timecode]');
	elems.each(function(item, index){
		item.addEvent('click', function() {
			update_timecode();
		});
	});
});
window.addEvent('domready', function() {
	focusField('jform_desc');
});
function focusField(id){
    var inputField = document.getElementById(id);
    if (inputField != null && inputField.value.length != 0){
        if (inputField.createTextRange){
            var FieldRange = inputField.createTextRange();
            FieldRange.moveStart('character',inputField.value.length);
            FieldRange.collapse();
            FieldRange.select();
        }else if (inputField.selectionStart || inputField.selectionStart == '0') {
            var elemLen = inputField.value.length;
            inputField.selectionStart = elemLen;
            inputField.selectionEnd = elemLen;
            inputField.focus();
        }
    }else{
        inputField.focus();
    }
}
</script>

	 	<form method="post" action="index.php" id="adminForm" name="adminForm">
	 	<div class="col <?php if(version_compare(JVERSION,'3.0','lt')):  ?>width-60  <?php endif; ?>span8 form-horizontal fltlft">
		  <fieldset class="adminform">
			<legend><?php echo JText::_( 'COM_INSTEON_DETAILS' ); ?></legend>
							
				<?php echo $this->form->getLabel('description'); ?>
				
				<?php echo $this->form->getInput('description');  ?>
					
				<?php echo $this->form->getLabel('timecode'); ?>
				
				<?php echo $this->form->getInput('timecode');  ?>
					
				<?php echo $this->form->getLabel('timeoffset'); ?>
				
				<?php echo $this->form->getInput('timeoffset');  ?>
					
				<?php echo $this->form->getLabel('stime'); ?>
				
				<?php echo $this->form->getInput('stime');  ?>
					
				<label id="jform_days-lbl" for="jform_days" title=""><?php echo JText::_( 'COM_INSTEON_DAYS' );?></label>
				<fieldset id="jform_days" class="radio inputbox">
				<table>
				<tr>
				<td><?php echo $this->form->getLabel('dmon'); ?></td>
				<td><?php echo $this->form->getLabel('dtue'); ?></td>
				<td><?php echo $this->form->getLabel('dwed'); ?></td>
				<td><?php echo $this->form->getLabel('dthu'); ?></td>
				<td><?php echo $this->form->getLabel('dfri'); ?></td>
				<td><?php echo $this->form->getLabel('dsat'); ?></td>
				<td><?php echo $this->form->getLabel('dsun'); ?></td>
				</tr>
				<tr>
				<td><?php echo $this->form->getInput('dmon');  ?></td>
				<td><?php echo $this->form->getInput('dtue');  ?></td>
				<td><?php echo $this->form->getInput('dwed');  ?></td>
				<td><?php echo $this->form->getInput('dthu');  ?></td>
				<td><?php echo $this->form->getInput('dfri');  ?></td>
				<td><?php echo $this->form->getInput('dsat');  ?></td>
				<td><?php echo $this->form->getInput('dsun');  ?></td>
				</table>
				</fieldset>
					
							
				<?php echo $this->form->getLabel('published'); ?>
				
				<?php echo $this->form->getInput('published');  ?>
			
						
          </fieldset>                      
        </div>
        <div class="col <?php if(version_compare(JVERSION,'3.0','lt')):  ?>width-30  <?php endif; ?>span2 fltrgt">
			        

        </div>                   
		<input type="hidden" name="option" value="com_insteon" />
	    <input type="hidden" name="cid[]" value="<?php echo $this->item->id ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="view" value="insteonschedules" />
		<?php echo JHTML::_( 'form.token' ); ?>
	</form>