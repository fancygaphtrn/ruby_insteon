<?php 
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.framework');
        
JToolBarHelper::title(   JText::_( 'COM_INSTEON_SERIAL_LOG' ), 'generic.png' );
JToolBarHelper::preferences('com_insteon', '550'); 
?>
<script type="text/javascript">  

window.addEvent('load', function() {
  var objDiv = document.getElementById("divlog");
  objDiv.scrollTop = objDiv.scrollHeight;
});
function clearForm(el) {
    $('filter').value = '';
    $('lines').value = '400';
    el.submit();
}
</script>

<form action="index.php" method="post" name="adminForm">
	<table>
		<tr>
			<td align="left" width="100%">
				<?php echo JText::_( 'COM_INSTEON_FILTER' ); ?>:
				<input type="text" name="filter" id="filter" value="<?php echo $this->filter;?>" class="text_area"/>
				<?php echo JText::_( 'COM_INSTEON_LINES' ); ?>:
				<input type="text" name="lines" id="lines" value="<?php echo $this->lines;?>" class="text_area"/>
				<button onclick="this.form.submit();"><?php echo JText::_( 'COM_INSTEON_GO' ); ?></button>
				<button onclick="clearForm(this.form);"><?php echo JText::_( 'COM_INSTEON_RESET' ); ?></button>
			</td>
			<td nowrap="nowrap">
				&nbsp;
			</td>
		</tr>
	</table>
<input type="hidden" name="option" value="com_insteon" />
<input type="hidden" name="view" value="seriallog" />
</form>

<div id="divlog" style="height:40em;overflow:auto;">

<?php
echo '<pre>';
echo $this->log;
echo '</pre>';
?>
</div>
<?php
      
?>    
