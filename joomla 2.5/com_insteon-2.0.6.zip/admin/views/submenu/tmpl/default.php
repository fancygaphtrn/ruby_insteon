<?php

// no direct access
defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.html.html.tabs' );
$hide = JRequest::getInt('hidemainmenu');
if (!$hide) {
?>
<div class="submenu-box">
<?php
$options = array(
    'onActive' => 'function(title, description){
        description.setStyle("display", "block");
        title.addClass("open").removeClass("closed");
    }',
    'onBackground' => 'function(title, description){
        description.setStyle("display", "none");
        title.addClass("closed").removeClass("open");
    }',
    'startOffset' => $this->offset,  // 0 starts on the first tab, 1 starts the second, etc...
    'useCookie' => true, // this must not be a string. Don't use quotes.
);
 
echo JHtml::_('tabs.start', 'default', $options);
 
echo JHtml::_('tabs.panel', JText::_('COM_INSTEON_ABOUT_TAB'), 'panel_1_id');
?>
<table width="100%">
<tr><td>
<?php echo JText::_('COM_INSTEON_ABOUT_TEXT');?>
</td></tr>
</table>

<?php 
echo JHtml::_('tabs.panel', JText::_('COM_INSTEON_MONITORING_TAB'), 'panel_2_id');
echo '<table>';

echo '<tr><td>';
echo '<a href="'.JRoute::_( 'index.php?option=com_insteon&view=insteonlog' ).'">'.JText::_('COM_INSTEON_INSTEON_LOG').'</a>';
echo '</td><td>';
echo JText::_('COM_INSTEON_INSTEON_LOG_TEXT');
echo '</td></tr>';

echo '<tr><td>';
echo '<a href="'.JRoute::_( 'index.php?option=com_insteon&view=seriallog' ).'">'.JText::_('COM_INSTEON_SERIAL_LOG').'</a>';
echo '</td><td>';
echo JText::_('COM_INSTEON_SERIAL_LOG_TEXT');
echo '</td></tr>';

echo '</table>';

echo JHtml::_('tabs.panel', JText::_('COM_INSTEON_CONFIGURATION_TAB'), 'panel_3_id');
echo '<table>';

echo '<tr><td>';
echo '<a href="'.JRoute::_( 'index.php?option=com_insteon&view=insteonareas' ).'">'.JText::_('COM_INSTEON_INSTEON_AREAS').'</a>';
echo '</td><td>';
echo JText::_('COM_INSTEON_INSTEON_AREAS_TEXT');
echo '</td>';

echo '<td>&nbsp;&nbsp;&nbsp;</td>';

echo '<td>';
echo '<a href="'.JRoute::_( 'index.php?option=com_insteon&view=insteonevents' ).'">'.JText::_('COM_INSTEON_INSTEON_EVENTS').'</a>';
echo '</td><td>';
echo JText::_('COM_INSTEON_INSTEON_EVENTS_TEXT');
echo '</td>';

echo '<td>';
echo '<a href="'.JRoute::_( 'index.php?option=com_insteon&view=insteonreport' ).'">'.JText::_('COM_INSTEON_INSTEON_REPORT').'</a>';
echo '</td><td>';
echo JText::_('COM_INSTEON_INSTEON_REPORT_TEXT');
echo '</td></tr>';

echo '<tr><td>';
echo '<a href="'.JRoute::_( 'index.php?option=com_insteon&view=insteondevices' ).'">'.JText::_('COM_INSTEON_INSTEON_DEVICES').'</a>';
echo '</td><td>';
echo JText::_('COM_INSTEON_INSTEON_DEVICES');
echo '</td>';

echo '<td></td>';

echo '<td>';
echo '<a href="'.JRoute::_( 'index.php?option=com_insteon&view=insteonscheduledetail' ).'">'.JText::_('COM_INSTEON_INSTEON_SCHEDULESDETAIL').'</a>';
echo '</td><td>';
echo JText::_('COM_INSTEON_INSTEON_SCHEDULESDETAIL_TEXT');
echo '</td>';

echo '<td></td></tr>';

echo '<tr><td>';
echo '<a href="'.JRoute::_( 'index.php?option=com_insteon&view=insteondeviceslinks' ).'">'.JText::_('COM_INSTEON_INSTEON_DEVICESLINKS').'</a>';
echo '</td><td>';
echo JText::_('COM_INSTEON_INSTEON_DEVICESLINKS_TEXT');
echo '</td>';

echo '<td></td>';

echo '<td>';
echo '<a href="'.JRoute::_( 'index.php?option=com_insteon&view=insteonschedules' ).'">'.JText::_('COM_INSTEON_INSTEON_SCHEDULES').'</a>';
echo '</td><td>';
echo JText::_('COM_INSTEON_INSTEON_SCHEDULES_TEXT');
echo '</td>';

echo '<td></td></tr>';

echo '<tr><td></td>';

echo '<td></td>';
echo '<td></td>';

echo '<td>';
echo '<a href="'.JRoute::_( 'index.php?option=com_insteon&view=insteoncommands' ).'">'.JText::_('COM_INSTEON_INSTEON_COMMANDS').'</a>';
echo '</td><td>';
echo JText::_('COM_INSTEON_INSTEON_COMMANDS_TEXT');
echo '</td>';

echo '<td></td></tr>';
       
echo '</table>';

echo JHtml::_('tabs.panel', JText::_('COM_INSTEON_TOOLS_TAB'), 'panel_4_id');
echo '<table>';

echo '<tr><td>';
echo '<a href="'.JRoute::_( 'index.php?option=com_insteon&view=daemonstatus' ).'">'.JText::_('COM_INSTEON_DAEMON_STATUS').'</a>';
echo '</td><td>';
echo JText::_('COM_INSTEON_DAEMON_STATUS_TEXT');
echo '</td></tr>';

echo '<tr><td>';
echo '<a href="http://'.$this->params->get( 'insteonaddress' ).':'.$this->params->get( 'insteonport' ).'/insteon?command=status" target="_blank">'.JText::_('COM_INSTEON_STATUS').'</a>';
echo '</td><td>';
echo JText::_('COM_INSTEON_STATUS_TEXT');
echo '</td></tr>';

echo '<tr><td>';
echo '<a href="'.JRoute::_( 'index.php?option=com_insteon&view=linkgraph' ).'">'.JText::_('COM_INSTEON_LINKGRAPH').'</a>';
echo '</td><td>';
echo JText::_('COM_INSTEON_LINKGRAPH_TEXT');
echo '</td></tr>';

echo '</table>';
 
echo JHtml::_('tabs.end');

?>
</div>
<?php } ?>
