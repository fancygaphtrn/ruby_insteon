<?php 
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.framework');
        
JToolBarHelper::title(   JText::_( 'COM_INSTEON_INSTEON_LOG' ), 'generic.png' );
JToolBarHelper::preferences('com_insteon', '550'); 
?>
<script type="text/javascript">  

window.addEvent('domready', function() {
  var divlog = $("divlog");
  resizeElementHeight(divlog);
  divlog.scrollTop = divlog.scrollHeight;
});
function clearForm(el) {
    $('ignorecase').value = 'Y';
    $('filter').value = '';
    $('lines').value = '400';
    el.submit();
}
function resizeElementHeight(element) {
  var height = 0;
  var body = window.document.body;
  if (window.innerHeight) {
      height = window.innerHeight;
  } else if (body.parentElement.clientHeight) {
      height = body.parentElement.clientHeight;
  } else if (body && body.clientHeight) {
      height = body.clientHeight;
  }
  element.style.height = ((height - element.offsetTop) + "px");
}
window.addEvent('domready', function() {
	focusField('filter');
});
function focusField(id){
    var inputField = document.getElementById(id);
    if (inputField != null && inputField.value.length != 0){
        if (inputField.createTextRange){
            var FieldRange = inputField.createTextRange();
            FieldRange.moveStart('character',inputField.value.length);
            FieldRange.collapse();
            FieldRange.select();
        }else if (inputField.selectionStart || inputField.selectionStart == '0') {
            var elemLen = inputField.value.length;
            inputField.selectionStart = elemLen;
            inputField.selectionEnd = elemLen;
            inputField.focus();
        }
    }else{
        inputField.focus();
    }
}

</script>

<form action="index.php" method="post" name="adminForm">
	<table>
		<tr>
			<td align="left" width="100%">
				<?php echo JText::_( 'COM_INSTEON_IGNORECASE' ); ?>:
				<input type="checkbox" name="ignorecase" id="ignorecase" <?php echo($this->ignorecase=='Y'?'checked="checked"':"")?> onchange="this.checked?this.value='Y':this.value='N';" value="<?php echo $this->ignorecase;?>" class="text_area"/>
				<?php echo JText::_( 'COM_INSTEON_FILTER' ); ?>:
				<input type="text" name="filter" id="filter" value="<?php echo $this->filter;?>" class="text_area"/>
				<?php echo JText::_( 'COM_INSTEON_LINES' ); ?>:
				<input type="text" name="lines" id="lines" value="<?php echo $this->lines;?>" class="text_area"/>
				<button onclick="this.form.submit();"><?php echo JText::_( 'COM_INSTEON_GO' ); ?></button>
				<button onclick="clearForm(this.form);"><?php echo JText::_( 'COM_INSTEON_RESET' ); ?></button>
			</td>
			<td nowrap="nowrap">
				&nbsp;
			</td>
		</tr>
	</table>
<input type="hidden" name="option" value="com_insteon" />
<input type="hidden" name="view" value="insteonlog" />
</form>

<div id="divlog" style="overflow:auto;">

<?php
echo '<pre>';
echo $this->log;
echo '</pre>';
?>
</div>
