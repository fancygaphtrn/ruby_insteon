<?php
/**
 * Joomla! 1.5 component Our home
 *
 * @version $Id: view.html.php 2010-03-08 14:10:53 svn $
 * @author Tod Price aka htrn
 * @package Joomla
 * @subpackage Our home
 * @license GNU/GPL
 *
 * Home Automation component
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Import Joomla! libraries
jimport( 'joomla.application.component.view');
class InsteonViewInsteonlog extends JView {
    function display($tpl = null) {

		$params = JComponentHelper::getParams( 'com_insteon' );
		$path = $params->get( 'insteonpath', 1 ); 
		$logfile = $params->get( 'logfile', 1 ); 

        $ignorecase = JRequest::getVar('ignorecase');
		$ignorecase = ($ignorecase === NULL?'N':$ignorecase); 
        $lines = JRequest::getVar('lines', '400');
        $filter = JRequest::getVar('filter', '');

		$case = ($ignorecase=='Y'?'-i':'');
        $cmd = "grep $case '$filter' $logfile | tail -n $lines ";
        $log = shell_exec($cmd);

        
        $this->assignRef('ignorecase', $ignorecase);		    
        $this->assignRef('filter', $filter);		    
        $this->assignRef('lines', $lines);		    
        $this->assignRef('log', $log);		    
        parent::display($tpl);
    }
}
?>