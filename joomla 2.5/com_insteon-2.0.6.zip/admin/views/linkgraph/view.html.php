<?php
/**
 * Joomla! 1.5 component Our home
 *
 * @version $Id: view.html.php 2010-03-08 14:10:53 svn $
 * @author Tod Price aka htrn
 * @package Joomla
 * @subpackage Our home
 * @license GNU/GPL
 *
 * Home Automation component
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Import Joomla! libraries
jimport( 'joomla.application.component.view');
class InsteonViewLinkgraph extends JView {
    function display($tpl = null) {
		$model = & JModel::getInstance('insteondeviceslinks', 'InsteonModel'); 
        $rows = $model->getGraph();

        $filename = JPATH_ROOT.'/tmp/graph.dot';

        $handle = fopen($filename, "w");
        if ($handle) {
            fputs($handle, "digraph G{\n");
            fputs($handle, "   size =\"12,12\"\n");
            fputs($handle, "   graph[fontsize =12]\n");
            fputs($handle, "   graph[fontname=\"Helvetica\"]\n");
            fputs($handle, "   node[fontsize =12]\n");
            fputs($handle, "   node[fontname=\"Helvetica\"]\n");
            fputs($handle, "   edge[fontsize =12]\n");
            fputs($handle, "   edge[fontname=\"Helvetica\"]\n");
            fputs($handle, "   rankdir=LR\n");
            $fdevice = '';
            foreach($rows as $row) {
                if ($fdevice != $row->fdevice) {
                    $fname = str_replace(' ', '_',$row->ffriendlyname).'_'.$row->fdevice;
                    if ($row->icontroller == 1) {
                        $label = "shape=polygon,sides=4,label=\"$row->afdescription $row->ffriendlyname\\n$row->fdevice\"";
                    } else {
                        $label = "label=\"$row->afdescription $row->ffriendlyname\\n$row->fdevice\"";
                    }
                    $data = "   $fname [$label]\n";
                    fputs($handle, $data);
                    $fdevice = $row->fdevice;
                }
            }
            foreach($rows as $row) {
                if (hexdec($row->flags) & 0x40) {
                    $fname = str_replace(' ', '_',$row->ffriendlyname).'_'.$row->fdevice;
                    $tname = str_replace(' ', '_',$row->tfriendlyname).'_'.$row->tdevice;
                    $data = "   $fname -> $tname [label=\"$row->devicegroup\"]\n";
                    fputs($handle, $data);
                }
            }
            fputs($handle, "}\n");
            fclose($handle);
            exec("dot -Tpng -O $filename");
        } else { 
			    return ("ERROR: Error writing file $filename");
        }
		$params = JComponentHelper::getParams( 'com_insteon' );
		$path = $params->get( 'tmpurl', '/tmp' ); 
        $this->assignRef('tmpurl', $path);		    
 
		parent::display($tpl);
    }

}
?>