<?php 
defined('_JEXEC') or die('Restricted access');
  JToolBarHelper::title( JText::_( 'COM_INSTEON_LINKGRAPH' ), 'generic.png' );
  JToolBarHelper::preferences('com_insteon', '550');  
?>
<div>
<img src="<?php echo $this->tmpurl?>/graph.dot.png" alt=""  />
</div>
