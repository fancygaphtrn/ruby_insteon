<?php 
defined('_JEXEC') or die('Restricted access');
  JToolBarHelper::title( JText::_( 'COM_INSTEON_INSTEON_REPORT' ), 'generic.png' );
  JToolBarHelper::preferences('com_insteon', '550');  
 
  $doc = JFactory::getDocument();
  $doc->addStyleSheet( JURI::base().'components/com_insteon/assets/insteonreport.css' );
?>
<pre>
<?php
//var_dump($this->rows); 
?>
</pre>
<div id='insteonreport' class='insteonreport'>
<?php
foreach($this->rows as $row) {
	echo '<span class="insteonreportevent">' ;
	switch ($row->eventtype) {
		case '0':
			echo JText::_( 'COM_INSTEON_INSTEON' ) . ' ';
			break;
		case '1':
			echo JText::_( 'COM_INSTEON_TIMED' ) . ' ';
		break;
	}
	echo JText::_( 'COM_INSTEON_EVENT' ) . ' ' ;
	echo $row->description . '</span> ';
	//echo '<br />';
	
	if (count($row->scheduledetails) > 0) {
		$firstschedule = true;
		echo '<span class="insteonreportscheduledetail">' ;
		foreach($row->scheduledetails as $sdrow) {
			//echo $sdrow->description . ' ';

			if (count($sdrow->schedules) > 0) {
				foreach($sdrow->schedules as $srow) {
					echo '<span class="insteonreportschedule">' ;
					if ($firstschedule == true) {
						$firstschedule = false;
					} else {
						echo ' '.JText::_( 'COM_INSTEON_AND').' ';
					}
					echo $srow->description;
					echo '</span> ';
				}
			}
		}
		echo '</span> ';
	}
	echo '<br />';
	if (count($row->commands) > 0) {
		foreach($row->commands as $crow) {
			echo '<span class="insteonreportcommand">' ;
			switch ($crow->commandtype) {
			case '0':
				echo JText::_( 'COM_INSTEON_INSTEON' ).' ';
				break;
			case '1':
				echo JText::_( 'COM_INSTEON_EMAIL').' '. $crow->email.' ' ;
				break;
			case '2':
				echo JText::_( 'COM_INSTEON_DIRECTV' ).' ';
				break;
			}
			echo JText::_( 'COM_INSTEON_COMMAND' ) . ' ' . $crow->description . ' ' . JText::_( 'COM_INSTEON_DELAY' ) . ' ' . $crow->delay . '<br />';
					echo '</span> ';
		}
	}
	echo '<br />';
}
?>
</div>