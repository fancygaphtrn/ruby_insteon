<?php
/**
 * Joomla! 1.5 component Our home
 *
 * @version $Id: view.html.php 2010-03-08 14:10:53 svn $
 * @author Tod Price aka htrn
 * @package Joomla
 * @subpackage Our home
 * @license GNU/GPL
 *
 * Home Automation component
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Import Joomla! libraries
jimport( 'joomla.application.component.view');
class InsteonViewDaemonstatus extends JView {
    function display($tpl = null) {
        
		$params = JComponentHelper::getParams( 'com_insteon' );
		$path = $params->get( 'insteonpath', '/usr/src/insteon' ); 
		$rubypath = $params->get( 'rubypath', '/usr/bin' ); 

        $insteoncommand = '';
        $command = JRequest::getVar('insteoncommand', '');
        switch ($command) {
          case "stop":
            $insteoncommand .= "Insteon $command ";
            $cmd = "cd $path;$rubypath/ruby insteond.rb $command";
            $insteoncommand .= $cmd."\n";
            $insteoncommand .= shell_exec($cmd);
            //$cmd = "cd $path;$rubypath/ruby serialserverd.rb $command";
            //$insteoncommand .= $cmd."\n";
            //$insteoncommand .= shell_exec($cmd);
            break;
          case "start":
          case "restart":
            //$insteoncommand .= "Insteon $command ";
            //$cmd = "cd $path;$rubypath/ruby serialserverd.rb $command";
            //$insteoncommand .= $cmd."\n";
            //$insteoncommand .= shell_exec($cmd);
            $cmd = "cd $path;$rubypath/ruby insteond.rb $command";
            $insteoncommand .= $cmd."\n";
            $insteoncommand .= shell_exec($cmd);
            break;
        }

        $cmd = "cd $path;$rubypath/ruby insteond.rb status";
        $insteonstatus = shell_exec($cmd);
        //$cmd = "cd $path;$rubypath/ruby serialserverd.rb status";
        //$serialstatus = shell_exec($cmd);
        $cmd = "/etc/init.d/ser2net status";
        $ser2netstatus = shell_exec($cmd);

        
        $this->assignRef('insteoncommand', $insteoncommand);		    
        $this->assignRef('insteonstatus', $insteonstatus);		    
        //$this->assignRef('serialstatus', $serialstatus);		    
        $this->assignRef('ser2netstatus', $ser2netstatus);		    
       parent::display($tpl);
    }
}
?>