<?php 
defined('_JEXEC') or die('Restricted access');

JToolBarHelper::title(   JText::_( 'COM_INSTEON_DAEMON_STATUS' ), 'generic.png' );
JToolBarHelper::preferences('com_insteon', '550'); 
?>
<table><tr>
<form action="index.php" method="post" name="insteonstopForm">
			<td>
				<button this.form.submit();"><?php echo JText::_( 'COM_INSTEON_STOP' ); ?></button>
			</td>
<input type="hidden" name="insteoncommand" value="stop" />
<input type="hidden" name="option" value="com_insteon" />
<input type="hidden" name="view" value="daemonstatus" />
</form>
<form action="index.php" method="post" name="insteonstartForm">
			<td>
				<button this.form.submit();"><?php echo JText::_( 'COM_INSTEON_START' ); ?></button>
			</td>
<input type="hidden" name="insteoncommand" value="start" />
<input type="hidden" name="option" value="com_insteon" />
<input type="hidden" name="view" value="daemonstatus" />
</form>
<form action="index.php" method="post" name="insteonreloadForm">
			<td>
				<button this.form.submit();"><?php echo JText::_( 'COM_INSTEON_RESTART' ); ?></button>
			</td>
<input type="hidden" name="insteoncommand" value="restart" />
<input type="hidden" name="option" value="com_insteon" />
<input type="hidden" name="view" value="daemonstatus" />
</form>
<form action="index.php" method="post" name="insteonreloadForm">
			<td>
				<button this.form.submit();"><?php echo JText::_( 'COM_INSTEON_STATUS' ); ?></button>
			</td>
<input type="hidden" name="insteoncommand" value="" />
<input type="hidden" name="option" value="com_insteon" />
<input type="hidden" name="view" value="daemonstatus" />
</form>
</tr></table>

<?php
echo '<pre>';
echo $this->insteoncommand;
echo '</pre>';
?>
<?php
echo '<pre>';
echo $this->insteonstatus;
echo '</pre>';
?>
<?php
echo '<pre>';
echo $this->serialstatus;
echo '</pre>';
?>
<?php
echo '<pre>';
echo $this->ser2netstatus;
echo '</pre>';
?>
