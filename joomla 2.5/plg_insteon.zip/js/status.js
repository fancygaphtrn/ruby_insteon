window.addEvent('domready', function() {
Slider.implement({ 
options: {/* 
    onTick: $empty(intPosition), 
    onChange: $empty(intStep), 
    onComplete: $empty(strStep),*/ 
    onTick: function(position){ 
            if (this.options.snap) position = this.toPosition(this.step); 
            this.knob.setStyle(this.property, position); 
    }, 
    snap: false, 
    offset: 0, 
    range: false, 
    wheel: false, 
    steps: 100, 
    startPercent: 0, 
    mode: 'horizontal' 
}, 

initialize: function(element, knob, options){ 
    this.setOptions(options); 
    this.element = document.id(element); 
    this.knob = document.id(knob); 
    this.previousChange = this.previousEnd = this.step = -1; 
    var offset, limit = {}, modifiers = {'x': false, 'y': false}; 
    switch (this.options.mode){ 
            case 'vertical': 
                    this.axis = 'y'; 
                    this.property = 'top'; 
                    offset = 'offsetHeight'; 
                    break; 
            case 'horizontal': 
                    this.axis = 'x'; 
                    this.property = 'left'; 
                    offset = 'offsetWidth'; 
    } 
    this.half = this.knob[offset] / 2; 
    this.full = this.element[offset] - this.knob[offset] + (this.options.offset * 2); 
    this.min = $chk(this.options.range[0]) ? this.options.range[0] : 0; 
    this.max = $chk(this.options.range[1]) ? this.options.range[1] : this.options.steps; 
    this.range = this.max - this.min; 
    this.steps = this.options.steps || this.full; 
    this.stepSize = Math.abs(this.range) / this.steps; 
    this.stepWidth = this.stepSize * this.full / Math.abs(this.range) ; 

    var startPos = this.full * ( this.options.startPercent * 0.01 ); 

    this.knob.setStyle('position', 'relative').setStyle(this.property, - this.options.offset + startPos); 

    modifiers[this.axis] = this.property; 
    limit[this.axis] = [- this.options.offset, this.full - this.options.offset]; 

    this.bound = { 
            clickedElement: this.clickedElement.bind(this), 
            scrolledElement: this.scrolledElement.bindWithEvent(this), 
            draggedKnob: this.draggedKnob.bind(this) 
    }; 

    var dragOptions = { 
            snap: 0, 
            limit: limit, 
            modifiers: modifiers, 
            onDrag: this.bound.draggedKnob, 
            onStart: this.bound.draggedKnob, 
            onBeforeStart: (function(){ 
                    this.isDragging = true; 
            }).bind(this), 
            onComplete: function(){ 
                    this.isDragging = false; 
                    this.draggedKnob(); 
                    this.end(); 
            }.bind(this) 
    }; 
    if (this.options.snap){ 
            dragOptions.grid = Math.ceil(this.stepWidth); 
            dragOptions.limit[this.axis][1] = this.full; 
    } 

    this.drag = new Drag(this.knob, dragOptions); 
    this.attach(); 
    } 
}); 

});


Request.Insteon = new Class({

	Implements: [Chain, Events, Options],

	options: {/*
		onRequest: function(src, scriptElement){},
		onComplete: function(data){},
		onSuccess: function(data){},
		onCancel: function(){},
		onTimeout: function(){},
		onError: function(){}, */
		onRequest: function(src){
			if (this.options.log && window.console && console.log){
				console.log('JSONP retrieving script with url:' + src);
			}
		},
		onError: function(src){
			if (this.options.log && window.console && console.warn){
				console.warn('JSONP '+ src +' will fail in Internet Explorer, which enforces a 2083 bytes length limit on URIs');
			}
		},
		url: '',
		map: '',
		callbackKey: 'callback',
		injectScript: document.head,
		data: '',
		link: 'ignore',
		timeout: 0,
		log: false
	},

	initialize: function(options){
		this.setOptions(options);
	},

	send: function(options){
		if (!Request.prototype.check.call(this, options)) return this;
		this.running = true;

		var type = typeOf(options);
		if (type == 'string' || type == 'element') options = {data: options};
		options = Object.merge(this.options, options || {});

		var data = options.data;
		switch (typeOf(data)){
			case 'element': data = document.id(data).toQueryString(); break;
			case 'object': case 'hash': data = Object.toQueryString(data);
		}

		var src = options.url +
			(options.url.test('\\?') ? '&' :'?') +
			(options.callbackKey) +
			'=Request.JSONP.request_map.request_'+options.map+
			(data ? '&' + data : '');

		if (src.length > 2083) this.fireEvent('error', src);

		Request.JSONP.request_map['request_'+options.map] = function(){
			this.success(arguments);
		}.bind(this);

		var script = this.getScript(src).inject(options.injectScript);
		this.fireEvent('request', [src, script]);

		if (options.timeout) this.timeout.delay(options.timeout, this);

		return this;
	},

	getScript: function(src){
		if (!this.script) this.script = new Element('script', {
			type: 'text/javascript',
			async: true,
			src: src
		});
		return this.script;
	},

	success: function(args){
		if (!this.running) return;
		this.clear()
			.fireEvent('complete', args).fireEvent('success', args)
			.callChain();
	},

	cancel: function(){
		if (this.running) this.clear().fireEvent('cancel');
		return this;
	},

	isRunning: function(){
		return !!this.running;
	},

	clear: function(){
		this.running = false;
		if (this.script){
			this.script.destroy();
			this.script = null;
		}
		return this;
	},

	timeout: function(){
		if (this.running){
			this.running = false;
			this.fireEvent('timeout', [this.script.get('src'), this.script]).fireEvent('failure').cancel();
		}
		return this;
	}

});

var insteonStatus = new Class({
	Implements: Options,
	options: {
		insteonaddress: '127.0.0.1', 
		insteonport: '9091',
		insteontime: 10000
	},
	initialize: function(options){
	  this.setOptions(options);
	  
      this.insteonaddress = this.options.insteonaddress;
	  this.insteonport = this.options.insteonport;
	  this.insteontime = this.options.insteontime;
	  
	  this.interval = null;
	  this.ajaxCheck= new Request.Insteon({
		method: 'get',
		map: 'insteon',
		link: 'chain',
		url: 'http://'+this.insteonaddress+':'+this.insteonport+'/insteon?command=json',
		log: true,
		onComplete: this.checkSuccess.bind(this),
		onFailure: function(xhr) {
			$("divstatus").innerHTML = '';
		}
	  });
	  this.ajaxCommand= new Request.Insteon({
		method: 'get',
		map: 'command',
		data: {
			device: '',
			command: ''
		},
 		url: 'http://'+this.insteonaddress+':'+this.insteonport+'/insteon',
		link: 'chain',
		log: true
	  });
	},
  check: function() {     
        var d=new Date()
       this.ajaxCheck.send();
  },
  checkSuccess: function(responseJSON, responseText) {
    status_table = $('status_table')
    if (!status_table) {
        $("divstatus").innerHTML = '';
        var status_table = new Element('div',{
            id: 'status_table'
        }).addClass('TP-status-table');
        var tableheader = new Element('div').addClass('TP-status-header').injectInside( status_table );
        new Element('div').set( 'html', Joomla.JText._('PLG_INSTEON_DEVICE') ).addClass('TP-status-device').injectInside( tableheader );
        new Element('div').set( 'html', Joomla.JText._('PLG_INSTEON_STATE') ).addClass('TP-status-state').injectInside( tableheader );
        new Element('div').set( 'html', Joomla.JText._('PLG_INSTEON_BRIGHTNESS') ).addClass('TP-status-brightness').injectInside( tableheader );
        status_table.injectInside($("divstatus"));
    }
    responseJSON.each(function(msg) { 
        status_row = $('status_row_'+msg.device);
        if (status_row) {
            toggle = status_row.getElement('.TP-status-state-toggle');
            toggle.removeClass('TP-status-state-on');
            toggle.removeClass('TP-status-state-off');
            if (msg.state == 'ON') {
                toggle.addClass('TP-status-state-on');
            } else {
                toggle.addClass('TP-status-state-off');
            }
            slide = status_row.retrieve('_slide',null);
            if (slide) {
                slide.previousEnd = Math.round(msg.brightness*2.55);
                slide.set(msg.brightness*2.55);
            }
            status_row.store('_msg',msg);

        } else {
            var status_row = new Element('div',{
                id: 'status_row_'+msg.device
            }).addClass('TP-status-row').injectInside( status_table );
            status_row.store('_msg',msg);
            new Element('div').set( 'html',msg.adescription+' '+msg.friendlyname ).addClass('TP-status-state-device').injectInside( status_row );

            tron = new Element('div');
            tron.addClass('TP-status-state-toggle').addClass('TP-status-state-type-'+msg.type.substr(0,2));
            if (msg.state == 'ON') {
                tron.addClass('TP-status-state-on');
            } else {
                tron.addClass('TP-status-state-off');
            }
            if (msg.type.substr(0,2) == '01' || msg.type.substr(0,2) == '02') {
                tron.set('style', 'cursor: pointer;');
                tron.addEvent('click', function(el){
                    if (el.target.hasClass('TP-status-state-on')) {
                        el.target.removeClass('TP-status-state-on');
                        el.target.addClass('TP-status-state-off');
                        msg = el.target.getParent('div.TP-status-row').retrieve('_msg',null);
                        device = msg.device;
                        command = '0262'+msg.device+'0F1300';
                        slide = el.target.getParent('div.TP-status-row').retrieve('_slide',null);
                        if (slide) {
                            slide.previousEnd = 0;
                            slide.set(0);
                        }
                    } else {
                        el.target.removeClass('TP-status-state-off');
                        el.target.addClass('TP-status-state-on');
                        msg = el.target.getParent('div.TP-status-row').retrieve('_msg',null);
                        device = msg.device;
                        command = '0262'+msg.device+'0F11FF';
                        slide = el.target.getParent('div.TP-status-row').retrieve('_slide',null);
                        if (slide) {
                            slide.previousEnd = 255;
                            slide.set(255);
                        }
                    }
                    this.sendcommand(device,command);
                    return true; 
                }.bind(this));
            }
            tron.injectInside( status_row );
 
            if (msg.type.substr(0,2) == '01') {
                trbrightness = new Element('div', {
                    'class': 'TP-status-state-brightness'
                }).injectInside(status_row);
                slider = new Element('div', {
                    'class': 'TP-status-state-slider'
                });
                knob = new Element('div', {
                    'class': 'TP-status-state-knob'
                }).injectInside(slider);
                slider.injectInside(trbrightness);

                var runSlider = function() { 
                    $$('.TP-status-state-slider').each(function(slider, i){
                        status_row = slider.getParent('div.TP-status-row');
                        msg = status_row.retrieve('_msg');
                        slide = status_row.retrieve('_slide',null);
                        if (!slide) {
                            slide = new Slider(slider,slider.getElement('.TP-status-state-knob'), {
                                range: [0, 255],
                                snap: true,
                                steps: 256,
                                startPercent: msg.brightness,
								/*initialStep: Math.round(msg.brightness*2.55),*/
                                onComplete: function(value){
                                    status_row = this.element.getParent('div.TP-status-row');
                                    msg = status_row.retrieve('_msg');
                                    tron = this.element.getParent('div.TP-status-row').getElement('.TP-status-state-toggle');
                                    if (tron) {
                                        tron.removeClass('TP-status-state-on');
                                        tron.removeClass('TP-status-state-off');
                                        if (value == 0) {
                                            tron.addClass('TP-status-state-off');
                                        } else {
                                            tron.addClass('TP-status-state-on');
                                        }
                                    }
                                    brightness = parseInt(value).toString(16).toUpperCase();
                                    if (brightness.length <= 1) brightness = '0'+brightness;
                                    device = msg.device;
                                    command = '0262'+msg.device+'0F11'+brightness;
                                    TP_cmd.check(device,command);
                                }
                            });
                            slider.addEvents({
                                mousedown: function(){
                                    //console.log('Mousedown');
                                    TP_f.Stop();
                                },
                                mouseup: function(){
                                    //console.log('Mouseup');
                                    TP_f.Start();
                                }
                            });
                            status_row.store('_slide',slide);
                        }
                    });
                };
                window.setTimeout(runSlider,100);

            } else {
                new Element('div', {
                    'class': 'TP-status-state-brightness'
                }).injectInside(status_row);
            }
        }
    },this);
  },
  sendcommand: function(device, command) {
    this.ajaxCommand.send({data: {device: device, command: command}});
  }
});

