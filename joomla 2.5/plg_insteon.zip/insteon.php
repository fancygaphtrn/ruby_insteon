<?php

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

/**
 * Vote plugin.
 *
 * @package		Joomla.Plugin
 * @subpackage	Content.vote
 */
class plgContentInsteon extends JPlugin {
	/**
	 * Constructor
	 *
	 * @access      protected
	 * @param       object  $subject The object to observe
	 * @param       array   $config  An array that holds the plugin configuration
	 * @since       1.5
	 */
	public function __construct(&$subject, $config) {
		parent::__construct($subject, $config);
		$this->loadLanguage();
	}
	
	/**
	 * @since	1.6
	 */
	public function onContentPrepare($context, &$row, &$params, $page = 0) {
		// simple performance check to determine whether bot should process further
		if (JString::strpos($row->text, 'insteon') === false) {
			return true;
		}
		
		// Get plugin info
		//$plugin = JPluginHelper::getPlugin('content', 'insteon');
		
		// expression to search for
		$regex = '/{insteon\s*.*?}/i';
		
		
		// check whether plugin has been unpublished
		if (!$this->params->get('enabled', 1)) {
			$row->text = preg_replace($regex, '', $row->text);
			return true;
		}
		
		// find all instances of plugin and put in $matches
		preg_match_all($regex, $row->text, $matches);
		
		// Number of plugins
		$count = count($matches[0]);
		
		// plugin only processes if there are any instances of the plugin in the text
		if ($count) {
			$document = JFactory::getDocument();
			$document->addScript(JURI::base() . 'plugins/content/insteon/js/status.js');
			$document->addStyleSheet(JURI::base() . 'plugins/content/insteon/css/status.css');
			$document->addScript(JURI::base() . 'plugins/content/insteon/js/status.js');

			$script  = "window.addEvent('domready', function() {\n";
			$script .= "  iStatus = new insteonStatus({insteonaddress: '".$this->params->get('insteonaddress')."',insteonport: '".$this->params->get('insteonport')."',insteontime: '".$this->params->get('insteontime')."'});\n";
			$script .= "  iStatus.check();\n";
			$script .= "  var periodicalID;\n";
			$script .= "  var insteonbegin = function() {\n";
			$script .= "	  iStatus.check();\n";
			$script .= "  };\n";
			$script .= "  periodicalID = insteonbegin.periodical(".$this->params->get('insteontime').");\n";
			$script .= "});\n";
			$script .= "window.addEvent('unload', function() {\n";
			$script .= "  clear(periodicalID);\n";
			$script .= "});\n";

			$document->addScriptDeclaration($script);

			$lang = JFactory::getLanguage();
			$extension = 'plg_content_insteon';
			$base_dir = JPATH_SITE;
			$reload = true;
			$lang->load($extension, $base_dir, null, $reload);

			JText::script('PLG_INSTEON_DEVICE');
			JText::script('PLG_INSTEON_STATE');
			JText::script('PLG_INSTEON_BRIGHTNESS');
			JText::script('PLG_INSTEON_ON');
			JText::script('PLG_INSTEON_OFF');
			
			foreach ($matches[0] as $id) {
				$txt       = $this->plgContentProcessInsteon();
				$row->text = preg_replace($regex, $txt, $row->text);
			}
			
		}
	}
	
	function plgContentProcessInsteon() {
		ob_start();
?>


<div id="divstatus">
</div>
<?php
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
}
?>